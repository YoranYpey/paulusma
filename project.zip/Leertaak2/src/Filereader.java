import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class Filereader {
	
	private static List<String> lines;
	
	public static void main(String[] args) throws IOException {
		String filepath = "test.txt";
		lines = Files.readAllLines(Paths.get(filepath));
		int size = lines.size();
		for(int i=0; i < size;i++) {
			System.out.println(lines.get(i));
		}
	}
	public static List<String> getList() {
		return lines;
	}

}
