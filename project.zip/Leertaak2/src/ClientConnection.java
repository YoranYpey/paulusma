import java.io.InputStream;
import java.sql.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.*;

import org.xml.sax.InputSource;

import java.lang.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.Socket;
import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


public class ClientConnection implements Runnable{

	/**
	 * @param client
	 * This is the socket the client communicates over with the server.
	 */

	public Socket client;
	public int client_no;
	public Server server;
	
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost/unwdmi";

	//  Database credentials
	static final String USER = "root";
	static final String PASS = "";
	
	public ClientConnection(Socket client,int client_no,Server server) {
		this.client = client;
		this.client_no = client_no;
		this.server = server;
		System.out.println("Ready to receive data from client number: "+client_no);
	}
	
	public void run() {
		try {
			String clientMessage = null;
			BufferedReader fromClient = new BufferedReader(new InputStreamReader(client.getInputStream(),"UTF-8"));
			int counter = 0;
			while ((clientMessage = fromClient.readLine())!= null) {
				if (clientMessage.equals("	<MEASUREMENT>")) {
					ArrayList<String>MessageList = new ArrayList<String>();
					System.out.println("Received a new XML-Entry from: "+client_no);
					while(counter<14) {
					clientMessage = fromClient.readLine();
					MessageList.add(clientMessage);
					counter++;
					}
				if(counter == 14) {
					server.handleArrayList(MessageList);
					counter =0;
					}
				}
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		
}
	/*
	public void handleArrayList(ArrayList<String> messages) {
		
		ArrayList<String>MessageList = new ArrayList<String>();
		for (String message : messages) {
		String newMessage = message.replaceAll("[^\\d.:-]", "");
		MessageList.add(newMessage);
		}
		String stn 	= 	MessageList.get(0);
		System.out.println("De STN is: "+stn);
		
		String date = 	MessageList.get(1);
		System.out.println("De date is: "+date);
		
		String time	=	MessageList.get(2);
		System.out.println("De time is: "+time);
		
		String temp = 	MessageList.get(3);
		System.out.println("De temp is: "+temp);
		
		String dewp = 	MessageList.get(4);
		System.out.println("De dewp is: "+dewp);
		
		String stp  = 	MessageList.get(5);
		System.out.println("De stp is: "+stp);
		
		String slp  = 	MessageList.get(6);
		System.out.println("De slp is: "+slp);
		
		String visib=	MessageList.get(7);
		System.out.println("De visib is: "+visib);
		
		String wdsp =	MessageList.get(8);
		System.out.println("De wdsp is: "+wdsp);
		
		String prcp	=	MessageList.get(9);
		System.out.println("De prcp is: "+prcp);
		
		String sndp = 	MessageList.get(10);
		System.out.println("De sndp is: "+sndp);
		
		String frshtt = MessageList.get(11);
		System.out.println("De frshtt is: "+frshtt);
		
		String cldc   = MessageList.get(12);
		System.out.println("De cldc is: "+cldc);
		
		String wnddir = MessageList.get(13);
		System.out.println("De wnddir is: "+wnddir);

		System.out.println("End of XML-Message from client.");
		
	//Insert into database	
	 try{
		//Connect to database
		 Class.forName(JDBC_DRIVER);
		
		System.out.println("Connecting to database Weatherdata");
		Connection c = (Connection) DriverManager.getConnection(DB_URL, USER, PASS);
		System.out.println("Connected database successfully...");
		Statement s = c.createStatement();
		System.out.println("Trying to insert the data into the database");
		s.executeUpdate("INSERT INTO `testtabel`(stn,date,time,temp,dewp,stp,slp,visib,wdsp,prcp,sndp,frshtt,cldc,wnddir) VALUE ('"+stn+"','"+date+"','"+time+"','"+temp+"','"+dewp+"','"+stp+"','"+slp+"','"+visib+"','"+wdsp+"','"+prcp+"','"+sndp+"','"+frshtt+"','"+cldc+"','"+wnddir+"')");       
	 } catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
*/
}



	
