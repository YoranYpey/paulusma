import java.sql.*;
import java.util.ArrayList;

import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilderFactory;
import jdk.internal.org.xml.sax.InputSource;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.io.ObjectInputStream;
import java.io.StringReader;



public class Server {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String URL_DB = "jdbc:mysql://localhost/unwdmi";
	
	//  Database credentials
	static final String USER = "root";
	static final String PASS = "";
	
	//serverSockets
	private ServerSocket serverSocket = null;
	private Socket client = null;
	
	public int client_no = 0;
	
	public int successfulltranfer = 0;
	public int dataloss = 0;
   
public synchronized void handleArrayList(ArrayList<String> messages) {
		
		ArrayList<String>MessageList = new ArrayList<String>();
		for (String message : messages) {
		String newMessage = message.replaceAll("[^\\d.:-]", "");
		MessageList.add(newMessage);
		}
		String stn 	= 	MessageList.get(0);
		System.out.println("De STN is: "+stn);
		
		String date = 	MessageList.get(1);
		System.out.println("De date is: "+date);
		
		String time	=	MessageList.get(2);
		System.out.println("De time is: "+time);
		
		String temp = 	MessageList.get(3);
		System.out.println("De temp is: "+temp);
		
		String dewp = 	MessageList.get(4);
		System.out.println("De dewp is: "+dewp);
		
		String stp  = 	MessageList.get(5);
		System.out.println("De stp is: "+stp);
		
		String slp  = 	MessageList.get(6);
		System.out.println("De slp is: "+slp);
		
		String visib=	MessageList.get(7);
		System.out.println("De visib is: "+visib);
		
		String wdsp =	MessageList.get(8);
		System.out.println("De wdsp is: "+wdsp);
		
		String prcp	=	MessageList.get(9);
		System.out.println("De prcp is: "+prcp);
		
		String sndp = 	MessageList.get(10);
		System.out.println("De sndp is: "+sndp);
		
		String frshtt = MessageList.get(11);
		System.out.println("De frshtt is: "+frshtt);
		
		String cldc   = MessageList.get(12);
		System.out.println("De cldc is: "+cldc);
		
		String wnddir = MessageList.get(13);
		System.out.println("De wnddir is: "+wnddir);

		System.out.println("End of XML-Message from client.");
		
	//Insert into database	
	 try{
		//Connect to database
		 Class.forName(JDBC_DRIVER);
		
		System.out.println("Connecting to database Weatherdata");
		Connection c = (Connection) DriverManager.getConnection(URL_DB, USER, PASS);
		System.out.println("Connected database successfully...");
		Statement s = c.createStatement();
		System.out.println("Trying to insert the data into the database");
		s.executeUpdate("INSERT INTO `weatherdata`(stn,date,time,temp,dewp,stp,slp,visib,wdsp,prcp,sndp,frshtt,cldc,wnddir) VALUE ('"+stn+"','"+date+"','"+time+"','"+temp+"','"+dewp+"','"+stp+"','"+slp+"','"+visib+"','"+wdsp+"','"+prcp+"','"+sndp+"','"+frshtt+"','"+cldc+"','"+wnddir+"')");       
		successfulltranfer++;
		System.out.println("Data sucessfully transfered to the database "+successfulltranfer);
		s.close();
		c.close();
	 } catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		dataloss++;
		System.out.println("Dataloss Occured, number of dataloss is now: "+dataloss);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
	
		public void initialize_Server() {
	    	 int portNumber = 7789;
	    	 try {
	    		 serverSocket = new ServerSocket(portNumber);
	    		 System.out.println("Initialized the server on port "+portNumber);
	    	 }
	    	 catch(IOException e) {
	    		 System.out.println(e.getMessage());
	    		 System.out.println("Could not listen on port: "+portNumber);
	    	 }
		}	    
	    
		public void start_to_listen() { 
	    	
	    	 while(true) {
	    		 try {
	    			 client = serverSocket.accept();
	    			 client_no++;
	    		 	 }
	    		 catch(IOException e) {
	    			 System.err.println("Could not accept the request");
	    		 }
	    		 //start a new thread that handles the connection with the client.
	    		 Thread t1 = new Thread(new ClientConnection(client,client_no,this));
	    		 t1.start();
	    	 }
	    }
		
	    public static void main(String[] args){
	    	Server server = new Server();
	    	server.initialize_Server();
	    	server.start_to_listen();
	    }
	

}//end of connection
